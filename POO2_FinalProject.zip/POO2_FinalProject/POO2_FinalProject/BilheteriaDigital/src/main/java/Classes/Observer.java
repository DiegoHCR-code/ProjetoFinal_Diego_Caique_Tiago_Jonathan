
package Classes;

public interface Observer {
    void update();
}
